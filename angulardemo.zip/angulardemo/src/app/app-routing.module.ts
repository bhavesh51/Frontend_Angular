import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginRoutingModule } from './login/login-routing.module';
import { RegisterRoutingModule } from './register/register-routing.module';
import { DashboardRoutingModule } from './dashboard/dashboard-routing.module';

const routes: Routes = [
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes),LoginRoutingModule,RegisterRoutingModule,DashboardRoutingModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
