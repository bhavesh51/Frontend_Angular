import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register.component';


const registrationroutes: Routes = [
  {path: 'registration', component: RegisterComponent,}
];

@NgModule({
  imports: [
    RouterModule.forChild(registrationroutes)
  ],
  
  exports: [
    RouterModule
  ]
})
export class RegisterRoutingModule { }
